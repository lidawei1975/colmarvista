"""Output handling for resampling-based uncertainty analyses."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import cast

import numpy as np

from chemex.atomic import open_text_atomic, remove_paths_best_effort, write_text_atomic
from chemex.configuration.method_plan import ResamplingKind, ResamplingRequest
from chemex.containers.experiments import Experiments
from chemex.exceptions import ArtifactPublicationError, ChemExError
from chemex.messages import print_running_statistics
from chemex.optimize.direct_trf import AcceptedFitResult
from chemex.optimize.native_deterministic import NativeDeterministicFit
from chemex.optimize.native_resampling import (
    OperationTerminal,
    ReplicateDisposition,
    ReplicateOutcome,
    ResamplingAnalysisResult,
    ResamplingAnalysisSample,
    ResamplingAnalysisStatus,
    ResamplingAnalysisSummary,
    ResamplingDatasetManifest,
    ResamplingEvidence,
    ResamplingOperation,
    ResamplingPlan,
    ResamplingScheme,
    derive_resampling_analysis_result,
    derive_resampling_diagnostic_samples,
    execute_resampling_evidence,
)
from chemex.optimize.statistics_plot import write_resampling_plots
from chemex.parameters.parameterization import SealedParameterModel
from chemex.parameters.sealed import parameter_name_from_definition
from chemex.runtime import ExecutionSettings


@dataclass(frozen=True, slots=True)
class _ResamplingMethod:
    statistic_name: str
    message: str
    directory: str
    iterations: int


class NativeResamplingIncompleteError(ChemExError, RuntimeError):
    """Raised after truthful incomplete native statistics have been published."""

    def __init__(
        self,
        message: str,
        *,
        terminal: str = "failed",
        diagnostics_path: Path | None = None,
        samples_path: Path | None = None,
        failures_path: Path | None = None,
    ) -> None:
        super().__init__(message)
        self.terminal = terminal
        self.diagnostics_path = diagnostics_path
        self.samples_path = samples_path
        self.failures_path = failures_path


def _resampling_publication_error(
    operation: str,
    path: Path,
    error: OSError,
    *,
    samples_published: bool = False,
    failures_published: bool = False,
    diagnostics_published: bool = False,
    interrupted: bool = False,
) -> ArtifactPublicationError:
    failure = ArtifactPublicationError(operation, path, error)
    if interrupted:
        object.__setattr__(failure, "terminal", "interrupted")
    statistic_path = path.parent
    if samples_published:
        object.__setattr__(failure, "samples_path", statistic_path / "samples.tsv")
    if failures_published:
        object.__setattr__(failure, "failures_path", statistic_path / "failures.tsv")
    if diagnostics_published:
        object.__setattr__(
            failure,
            "diagnostics_path",
            statistic_path / "diagnostics.toml",
        )
    return failure


def _resampling_result_and_samples(
    operation: ResamplingOperation,
    accepted: AcceptedFitResult,
    method_message: str,
) -> tuple[ResamplingAnalysisResult | None, Sequence[ResamplingAnalysisSample]]:
    if operation.terminal is OperationTerminal.INTERRUPTED:
        return None, derive_resampling_diagnostic_samples(operation, accepted)
    result = derive_resampling_analysis_result(operation, accepted)
    if result is None:
        raise NativeResamplingIncompleteError(
            f"Native {method_message} produced no meaningful Analysis Result"
        )
    return result, result.samples


def _resampling_method(
    kind: ResamplingKind,
    request: ResamplingRequest,
) -> _ResamplingMethod:
    descriptions = {
        "mc": ("Monte Carlo", "MonteCarlo"),
        "bs": ("bootstrap", "Bootstrap"),
        "bsn": ("nucleus-based bootstrap", "BootstrapNS"),
    }
    message, directory = descriptions[kind]
    return _ResamplingMethod(kind, message, directory, request.replicates)


def _quote_toml_string(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _format_toml_string_list(values: list[str]) -> str:
    if not values:
        return "[]"
    return "[" + ", ".join(_quote_toml_string(value) for value in values) + "]"


def _format_toml_float(value: float) -> str:
    return f"{value:.5e}"


def _format_tsv_float(value: float) -> str:
    return "nan" if not np.isfinite(value) else f"{value:.5e}"


def _format_parameter_names(
    parameter_ids: list[str],
    parameter_model: SealedParameterModel,
) -> tuple[str, ...]:
    return tuple(
        str(parameter_name_from_definition(parameter_model.definitions[param_id]))
        for param_id in parameter_ids
    )


def _write_resampling_summary(
    path: Path,
    *,
    parameter_names: tuple[str, ...],
    summary: ResamplingAnalysisSummary,
) -> None:
    lines: list[str] = []
    for parameter_name, distribution in zip(
        parameter_names,
        summary.distributions,
        strict=True,
    ):
        lines.extend(
            [
                f"[{_quote_toml_string(parameter_name.strip('[]'))}]",
                'interval = "95% percentile"',
                f"sample_count = {distribution.sample_count}",
            ],
        )
        lines.extend(
            [
                f"mean = {_format_toml_float(distribution.mean)}",
                (
                    "standard_deviation = "
                    f"{_format_toml_float(distribution.standard_deviation)}"
                ),
                f"median = {_format_toml_float(distribution.median)}",
                (
                    "percentile_95_lower = "
                    f"{_format_toml_float(distribution.percentile_95_lower)}"
                ),
                (
                    "percentile_95_upper = "
                    f"{_format_toml_float(distribution.percentile_95_upper)}"
                ),
                (
                    "percentile_68_lower = "
                    f"{_format_toml_float(distribution.percentile_68_lower)}"
                ),
                (
                    "percentile_68_upper = "
                    f"{_format_toml_float(distribution.percentile_68_upper)}"
                ),
                (
                    "half_percentile_68_width = "
                    f"{_format_toml_float(distribution.half_percentile_68_width)}"
                ),
            ],
        )
        lines.append("")
    (path / "summary.toml").write_text("\n".join(lines), encoding="utf-8")


def _write_resampling_correlations(
    path: Path,
    *,
    parameter_names: tuple[str, ...],
    summary: ResamplingAnalysisSummary,
) -> np.ndarray:
    width = len(summary.parameter_ids)
    correlations = np.asarray(
        tuple(
            np.nan if item.value is None else item.value
            for item in summary.correlations
        ),
        dtype=np.float64,
    ).reshape((width, width))
    if not parameter_names:
        (path / "correlations.tsv").write_text("", encoding="utf-8")
        return correlations

    with (path / "correlations.tsv").open("w", encoding="utf-8") as fileout:
        fileout.write("parameter\t" + "\t".join(parameter_names) + "\n")
        for name, values in zip(parameter_names, correlations, strict=True):
            row = "\t".join(_format_tsv_float(value) for value in values)
            fileout.write(f"{name}\t{row}\n")
    return correlations


def _write_resampling_diagnostics(
    path: Path,
    *,
    method: str,
    fitmethod: str,
    requested_samples: int,
    completed_samples: int,
    workers: int,
    parameter_ids: list[str],
    engine: str | None = None,
    root_seed: int | None = None,
    status: str | None = None,
) -> None:
    lines = [
        f"method = {_quote_toml_string(method)}",
        f"fitmethod = {_quote_toml_string(fitmethod)}",
        f"requested_samples = {requested_samples}",
        f"completed_samples = {completed_samples}",
        f"workers = {workers}",
        f"parameters = {_format_toml_string_list(parameter_ids)}",
        'samples_file = "samples.tsv"',
        'summary_file = "summary.toml"',
        'correlations_file = "correlations.tsv"',
        'plots_file = "plots.pdf"',
    ]
    if engine is not None:
        lines.append(f"engine = {_quote_toml_string(engine)}")
    if root_seed is not None:
        lines.append(f"root_seed = {root_seed}")
    if status is not None:
        lines.append(f"status = {_quote_toml_string(status)}")
    write_text_atomic(path / "diagnostics.toml", "\n".join(lines) + "\n")


def _native_dataset(
    experiments: Experiments,
    fit: NativeDeterministicFit,
) -> ResamplingDatasetManifest:
    profiles = tuple(profile for experiment in experiments for profile in experiment)
    if len(profiles) != len(fit.engine.plan.profiles):
        raise RuntimeError(
            "Native resampling profile population differs from the accepted fit"
        )
    references: list[bool] = []
    nucleus_groups: list[str] = []
    descriptors: list[str] = []
    for profile, profile_plan in zip(profiles, fit.engine.plan.profiles, strict=True):
        if profile.data.size != profile_plan.observation_count:
            raise RuntimeError(
                "Native resampling profile shape differs from the accepted fit"
            )
        references.extend(bool(value) for value in profile.data.refs)
        nucleus_group = str(profile.spin_system.groups["i"])
        nucleus_groups.extend([nucleus_group] * profile.data.size)
        descriptors.extend(
            f"{profile_plan.identity}:{index}"
            for index in range(profile_plan.observation_count)
        )
    return ResamplingDatasetManifest(
        fit.engine.plan,
        tuple(
            float(value)
            for value in fit.accepted.evaluation_result.normalized_calculations
        ),
        tuple(references),
        tuple(nucleus_groups),
        tuple(descriptors),
    )


def _write_native_failures(path: Path, outcomes: Sequence[ReplicateOutcome]) -> bool:
    failed = tuple(outcome for outcome in outcomes if outcome.failure is not None)
    if not failed:
        return False
    with open_text_atomic(path / "failures.tsv") as output:
        output.write("ordinal\tdisposition\tcategory\tmessage\n")
        for outcome in failed:
            failure = outcome.failure
            if failure is None:
                continue
            message = failure.message.replace("\t", " ").replace("\n", " ")
            output.write(
                f"{outcome.ordinal}\t{outcome.disposition.value}\t"
                f"{failure.category}\t{message}\n"
            )
    return True


def _write_native_samples(
    path: Path,
    parameter_names: tuple[str, ...],
    samples: Sequence[ResamplingAnalysisSample],
) -> None:
    with open_text_atomic(path / "samples.tsv") as output:
        output.write("\t".join((*parameter_names, "chisqr")) + "\n")
        for sample in samples:
            output.write(
                "\t".join(
                    _format_tsv_float(value)
                    for value in (*sample.values, float(sample.chi_square))
                )
                + "\n"
            )


def _disposition_counts(
    source: ResamplingEvidence | ResamplingAnalysisResult | None = None,
    *,
    unstarted: int = 0,
) -> tuple[tuple[str, int], ...]:
    """Map authoritative dispositions to their diagnostic representation."""
    if source is None:
        return (
            ("completed_samples", 0),
            ("failed_samples", 0),
            ("cancelled_samples", 0),
            ("interrupted_samples", 0),
            ("unstarted_samples", unstarted),
        )
    return tuple(
        (name, source.disposition_count(disposition))
        for name, disposition in (
            ("completed_samples", ReplicateDisposition.SUCCEEDED),
            ("failed_samples", ReplicateDisposition.FAILED),
            ("cancelled_samples", ReplicateDisposition.CANCELLED),
            ("interrupted_samples", ReplicateDisposition.INTERRUPTED),
            ("unstarted_samples", ReplicateDisposition.NOT_STARTED),
        )
    )


def _write_native_state_diagnostics(
    path: Path,
    *,
    method: _ResamplingMethod,
    workers: int,
    parameter_ids: tuple[str, ...],
    root_seed: int,
    status: str,
    sample_counts: Sequence[tuple[str, int]] = (),
    terminal: str | None = None,
    failure: BaseException | None = None,
) -> None:
    lines = [
        f"method = {_quote_toml_string(method.message)}",
        'fitmethod = "trf"',
        'engine = "native direct TRF"',
        f"status = {_quote_toml_string(status)}",
        f"requested_samples = {method.iterations}",
        f"workers = {workers}",
        f"parameters = {_format_toml_string_list(list(parameter_ids))}",
        f"root_seed = {root_seed}",
    ]
    if terminal is not None:
        lines.append(f"terminal = {_quote_toml_string(terminal)}")
    lines.extend(f"{name} = {count}" for name, count in sample_counts)
    if status == "incomplete":
        if (path / "samples.tsv").is_file():
            lines.append('samples_file = "samples.tsv"')
        if (path / "failures.tsv").is_file():
            lines.append('failures_file = "failures.tsv"')
    if failure is not None:
        message = str(failure).replace("\n", " ")
        lines.extend(
            (
                f"failure_type = {_quote_toml_string(type(failure).__name__)}",
                f"failure_message = {_quote_toml_string(message)}",
            )
        )
    write_text_atomic(path / "diagnostics.toml", "\n".join(lines) + "\n")


def _clear_native_statistics_artifacts(path: Path) -> None:
    for name in (
        "summary.toml",
        "samples.tsv",
        "correlations.tsv",
        "diagnostics.toml",
        "plots.pdf",
        "failures.tsv",
    ):
        (path / name).unlink(missing_ok=True)


def _run_native_resampling_method(  # noqa: C901 - closed execution/publication lifecycle
    experiments: Experiments,
    path: Path,
    method: _ResamplingMethod,
    fit: NativeDeterministicFit,
    *,
    execution: ExecutionSettings,
    root_seed: int,
) -> None:
    statistic_path = path / "Statistics" / method.directory
    parameter_ids = fit.accepted.controlled_ids
    parameter_names = _format_parameter_names(list(parameter_ids), fit.parameter_model)
    worker_count = min(execution.workers, method.iterations)
    try:
        statistic_path.mkdir(parents=True, exist_ok=True)
        _clear_native_statistics_artifacts(statistic_path)
        _write_native_state_diagnostics(
            statistic_path,
            method=method,
            workers=worker_count,
            parameter_ids=parameter_ids,
            root_seed=root_seed,
            status="running",
        )
    except OSError as error:
        filename = error.filename
        destination = Path(filename) if isinstance(filename, str) else statistic_path
        raise ArtifactPublicationError(
            "prepare resampling diagnostics",
            destination,
            error,
        ) from error
    try:
        dataset = _native_dataset(experiments, fit)
        width = max(6, len(str(method.iterations)))
        plan = ResamplingPlan.for_accepted(
            fit.accepted,
            dataset=dataset,
            source_problem=fit.problem,
            parameterization=fit.parameterization,
            source_engine=fit.engine,
            scheme=ResamplingScheme(method.statistic_name),
            replicate_count=method.iterations,
            replicate_structural_identities=tuple(
                f"production-replicate-{index:0{width}d}"
                for index in range(method.iterations)
            ),
            replicate_component_identities=tuple(
                (f"production-direct-trf-{index:0{width}d}",)
                for index in range(method.iterations)
            ),
            root_seed=root_seed,
            output_scope=fit.problem.commit_scope,
            output_units=("native",) * len(fit.problem.commit_scope),
            minimum_successful_count=method.iterations,
            strategy_settings=(
                (
                    "objective_request_budget",
                    str(fit.objective_request_budget),
                ),
            ),
        )
        operation = execute_resampling_evidence(
            fit.accepted,
            plan,
            execution=execution,
        )
    except (Exception, KeyboardInterrupt) as error:
        terminal = "interrupted" if isinstance(error, KeyboardInterrupt) else "failed"
        try:
            _write_native_state_diagnostics(
                statistic_path,
                method=method,
                workers=worker_count,
                parameter_ids=parameter_ids,
                root_seed=root_seed,
                status="incomplete",
                sample_counts=_disposition_counts(unstarted=method.iterations),
                terminal=terminal,
                failure=error,
            )
        except OSError as publication_error:
            if isinstance(error, KeyboardInterrupt):
                raise _resampling_publication_error(
                    "publish interrupted resampling diagnostics",
                    statistic_path / "diagnostics.toml",
                    publication_error,
                    interrupted=True,
                ) from publication_error
            error.add_note(
                "ChemEx could not publish incomplete resampling diagnostics: "
                f"{type(publication_error).__name__}: {publication_error}"
            )
            remove_paths_best_effort(
                (statistic_path / "diagnostics.toml",),
                error,
            )
        except (Exception, KeyboardInterrupt) as publication_error:  # noqa: BLE001
            error.add_note(
                "ChemEx could not publish incomplete resampling diagnostics: "
                f"{type(publication_error).__name__}: {publication_error}"
            )
            remove_paths_best_effort(
                (statistic_path / "diagnostics.toml",),
                error,
            )
        raise
    evidence = operation.evidence
    if evidence is None:
        error = NativeResamplingIncompleteError(
            f"Native {method.message} produced no replicate evidence",
            terminal=operation.terminal.value,
        )
        try:
            _write_native_state_diagnostics(
                statistic_path,
                method=method,
                workers=worker_count,
                parameter_ids=parameter_ids,
                root_seed=root_seed,
                status="incomplete",
                sample_counts=_disposition_counts(unstarted=method.iterations),
                terminal=operation.terminal.value,
                failure=error,
            )
        except OSError as publication_error:
            raise ArtifactPublicationError(
                "publish incomplete resampling diagnostics",
                statistic_path / "diagnostics.toml",
                publication_error,
            ) from publication_error
        error.diagnostics_path = statistic_path / "diagnostics.toml"
        raise error
    samples_published = False
    failures_published = False
    diagnostics_published = False
    publication_operation: str | None = None
    publication_path: Path | None = None
    result: ResamplingAnalysisResult | None = None
    operational_interruption = operation.terminal is OperationTerminal.INTERRUPTED
    try:
        result, analysis_samples = _resampling_result_and_samples(
            operation,
            fit.accepted,
            method.message,
        )
        complete = (
            result is not None and result.status is ResamplingAnalysisStatus.COMPLETE
        )
        sample_rows = [sample.values for sample in analysis_samples]
        chisqr_rows = [sample.chi_square for sample in analysis_samples]
        samples = np.asarray(sample_rows, dtype=float).reshape(
            (len(sample_rows), len(parameter_ids))
        )
        publication_operation = "publish resampling samples"
        publication_path = statistic_path / "samples.tsv"
        _write_native_samples(statistic_path, parameter_names, analysis_samples)
        samples_published = True
        if not complete:
            publication_operation = "publish resampling failures"
            publication_path = statistic_path / "failures.tsv"
            failures_published = _write_native_failures(
                statistic_path,
                evidence.outcomes,
            )
            disposition_source = evidence if result is None else result
            publication_operation = "publish incomplete resampling diagnostics"
            publication_path = statistic_path / "diagnostics.toml"
            _write_native_state_diagnostics(
                statistic_path,
                method=method,
                workers=worker_count,
                parameter_ids=parameter_ids,
                root_seed=root_seed,
                status="incomplete",
                sample_counts=_disposition_counts(disposition_source),
                terminal=operation.terminal.value,
            )
            diagnostics_published = True
        else:
            summary = cast("ResamplingAnalysisSummary", result.summary)
            publication_operation = "publish the resampling summary"
            publication_path = statistic_path / "summary.toml"
            _write_resampling_summary(
                statistic_path,
                parameter_names=parameter_names,
                summary=summary,
            )
            publication_operation = "publish resampling correlations"
            publication_path = statistic_path / "correlations.tsv"
            correlations = _write_resampling_correlations(
                statistic_path,
                parameter_names=parameter_names,
                summary=summary,
            )
            publication_operation = "publish resampling plots"
            publication_path = statistic_path / "plots.pdf"
            write_resampling_plots(
                statistic_path,
                method=method.message,
                fitmethod="trf",
                parameter_names=parameter_names,
                samples=samples,
                chisqr_values=np.asarray(chisqr_rows, dtype=float),
                correlations=correlations,
                summary=summary,
                requested_samples=method.iterations,
                completed_samples=result.disposition_count(
                    ReplicateDisposition.SUCCEEDED
                ),
            )
            publication_operation = "publish resampling diagnostics"
            publication_path = statistic_path / "diagnostics.toml"
            _write_resampling_diagnostics(
                statistic_path,
                method=method.message,
                fitmethod="trf",
                requested_samples=method.iterations,
                completed_samples=result.disposition_count(
                    ReplicateDisposition.SUCCEEDED
                ),
                workers=worker_count,
                parameter_ids=list(parameter_ids),
                engine="native direct TRF",
                root_seed=root_seed,
                status="complete",
            )
    except (Exception, KeyboardInterrupt) as error:
        artifacts_to_remove = ["summary.toml", "correlations.tsv", "plots.pdf"]
        if not samples_published:
            artifacts_to_remove.append("samples.tsv")
        if not failures_published:
            artifacts_to_remove.append("failures.tsv")
        remove_paths_best_effort(
            (statistic_path / name for name in artifacts_to_remove),
            error,
        )
        terminal = (
            "interrupted"
            if operational_interruption or isinstance(error, KeyboardInterrupt)
            else "failed"
        )
        disposition_source = evidence if result is None else result
        if terminal == "interrupted" and not samples_published:
            try:
                diagnostic_samples = derive_resampling_diagnostic_samples(
                    operation,
                    fit.accepted,
                )
                _write_native_samples(
                    statistic_path,
                    parameter_names,
                    diagnostic_samples,
                )
                samples_published = True
            except OSError as publication_error:
                raise _resampling_publication_error(
                    "publish interrupted resampling samples",
                    statistic_path / "samples.tsv",
                    publication_error,
                    failures_published=failures_published,
                    diagnostics_published=diagnostics_published,
                    interrupted=True,
                ) from publication_error
            except (Exception, KeyboardInterrupt):  # noqa: BLE001
                error.add_note(
                    "ChemEx could not publish interrupted resampling samples."
                )
                remove_paths_best_effort(
                    (statistic_path / "samples.tsv",),
                    error,
                )
        if terminal == "interrupted" and not failures_published:
            try:
                failures_published = _write_native_failures(
                    statistic_path,
                    evidence.outcomes,
                )
            except OSError as publication_error:
                raise _resampling_publication_error(
                    "publish interrupted resampling failures",
                    statistic_path / "failures.tsv",
                    publication_error,
                    samples_published=samples_published,
                    diagnostics_published=diagnostics_published,
                    interrupted=True,
                ) from publication_error
            except (Exception, KeyboardInterrupt):  # noqa: BLE001
                error.add_note(
                    "ChemEx could not publish interrupted resampling failures."
                )
                remove_paths_best_effort(
                    (statistic_path / "failures.tsv",),
                    error,
                )
        try:
            _write_native_state_diagnostics(
                statistic_path,
                method=method,
                workers=worker_count,
                parameter_ids=parameter_ids,
                root_seed=root_seed,
                status="incomplete",
                sample_counts=_disposition_counts(disposition_source),
                terminal=terminal,
                failure=error,
            )
            diagnostics_published = True
        except OSError as publication_error:
            if terminal == "interrupted":
                raise _resampling_publication_error(
                    "publish incomplete resampling diagnostics",
                    statistic_path / "diagnostics.toml",
                    publication_error,
                    samples_published=samples_published,
                    failures_published=failures_published,
                    interrupted=True,
                ) from publication_error
            if isinstance(error, NativeResamplingIncompleteError):
                remove_paths_best_effort(
                    (statistic_path / "diagnostics.toml",),
                    error,
                )
                raise _resampling_publication_error(
                    "publish incomplete resampling diagnostics",
                    statistic_path / "diagnostics.toml",
                    publication_error,
                    samples_published=samples_published,
                    failures_published=failures_published,
                ) from publication_error
            if (
                isinstance(error, OSError)
                and publication_operation is not None
                and publication_path is not None
            ):
                failure = _resampling_publication_error(
                    publication_operation,
                    publication_path,
                    error,
                    samples_published=samples_published,
                    failures_published=failures_published,
                )
                failure.add_note(
                    "ChemEx also could not publish incomplete resampling diagnostics: "
                    f"{type(publication_error).__name__}: {publication_error}"
                )
                remove_paths_best_effort(
                    (statistic_path / "diagnostics.toml",),
                    failure,
                )
                raise failure from error
            error.add_note(
                "ChemEx could not publish incomplete resampling diagnostics: "
                f"{type(publication_error).__name__}: {publication_error}"
            )
            remove_paths_best_effort(
                (statistic_path / "diagnostics.toml",),
                error,
            )
        except (Exception, KeyboardInterrupt):  # noqa: BLE001
            error.add_note(
                "ChemEx could not publish incomplete resampling diagnostics."
            )
            remove_paths_best_effort(
                (statistic_path / "diagnostics.toml",),
                error,
            )
        if (
            isinstance(error, OSError)
            and publication_operation is not None
            and publication_path is not None
        ):
            publication_error = _resampling_publication_error(
                publication_operation,
                publication_path,
                error,
                samples_published=samples_published,
                failures_published=failures_published,
                diagnostics_published=diagnostics_published,
            )
            raise publication_error from error
        if operational_interruption and not isinstance(error, KeyboardInterrupt):
            interrupted_error = NativeResamplingIncompleteError(
                f"Native {method.message} completed {evidence.successful_count} of "
                f"{method.iterations} requested replicates",
                terminal="interrupted",
                diagnostics_path=(
                    statistic_path / "diagnostics.toml"
                    if diagnostics_published
                    else None
                ),
                samples_path=(
                    statistic_path / "samples.tsv" if samples_published else None
                ),
                failures_path=(
                    statistic_path / "failures.tsv" if failures_published else None
                ),
            )
            interrupted_error.add_note(
                "ChemEx could not publish interrupted resampling output."
            )
            raise interrupted_error from error
        if diagnostics_published:
            object.__setattr__(
                error,
                "diagnostics_path",
                statistic_path / "diagnostics.toml",
            )
        if samples_published:
            object.__setattr__(
                error,
                "samples_path",
                statistic_path / "samples.tsv",
            )
        if failures_published:
            object.__setattr__(
                error,
                "failures_path",
                statistic_path / "failures.tsv",
            )
        raise
    if operational_interruption or (
        result is not None and result.status is ResamplingAnalysisStatus.INCOMPLETE
    ):
        raise NativeResamplingIncompleteError(
            f"Native {method.message} completed {evidence.successful_count} of "
            f"{method.iterations} requested replicates",
            terminal="interrupted" if operational_interruption else "failed",
            diagnostics_path=(
                statistic_path / "diagnostics.toml" if diagnostics_published else None
            ),
            samples_path=(
                statistic_path / "samples.tsv" if samples_published else None
            ),
            failures_path=(
                statistic_path / "failures.tsv" if failures_published else None
            ),
        )


def run_native_resampling(
    experiments: Experiments,
    path: Path,
    kind: ResamplingKind,
    request: ResamplingRequest,
    fit: NativeDeterministicFit,
    *,
    execution: ExecutionSettings | None = None,
    root_seed: int = 0,
) -> None:
    """Run one canonical resampling request from a committed native fit."""
    settings = ExecutionSettings() if execution is None else execution
    method = _resampling_method(kind, request)
    print_running_statistics(method.message)
    _run_native_resampling_method(
        experiments,
        path,
        method,
        fit,
        execution=settings,
        root_seed=root_seed,
    )
