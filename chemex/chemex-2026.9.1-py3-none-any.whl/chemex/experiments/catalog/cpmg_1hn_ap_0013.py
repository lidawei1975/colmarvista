from __future__ import annotations

from functools import reduce
from typing import ClassVar, Literal

import numpy as np
from pydantic import Field, computed_field

from chemex.configuration.base import ExperimentConfiguration, ToBeFitted
from chemex.configuration.conditions import ConditionsWithValidations
from chemex.configuration.data import RelaxationDataSettings
from chemex.configuration.experiment import CpmgSettings
from chemex.configuration.types import Delay, Frequency, PulseWidth
from chemex.containers.data import Data
from chemex.experiments.experiment_types import (
    ProfileCalculation,
    cpmg_type,
    register_experiment_type,
)
from chemex.nmr.basis import Basis
from chemex.nmr.spectrometer import Spectrometer
from chemex.parameters.spin_system import SpinSystem
from chemex.typing import Array

EXPERIMENT_NAME = "cpmg_1hn_ap_0013"


class Cpmg1HnAp0013Settings(CpmgSettings):
    """Settings for 1HN anti-phase CPMG experiment with 0013 variant."""

    name: Literal["cpmg_1hn_ap_0013"]
    time_t2: Delay = Field(description="Total CPMG relaxation delay (seconds)")
    carrier: Frequency = Field(description="1H carrier frequency (Hz)")
    pw90: PulseWidth = Field(description="1H 90-degree pulse width (seconds)")
    ncyc_max: int = Field(gt=0, description="Maximum number of CPMG cycles")
    taua: float = Field(
        default=2.38e-3,
        gt=0.0,
        description="Delay for coherence evolution (seconds)",
    )
    ipap_flg: bool = Field(default=False, description="IPAP experiment flag")
    eburp_flg: bool = Field(default=False, description="E-BURP pulse flag")
    reburp_flg: bool = Field(default=False, description="RE-BURP pulse flag")
    pw_eburp: float = Field(
        default=1.4e-3,
        gt=0.0,
        description="E-BURP pulse width (seconds)",
    )
    pw_reburp: float = Field(
        default=1.52e-3,
        gt=0.0,
        description="RE-BURP pulse width (seconds)",
    )
    time_equil_1: float = Field(
        default=0.0,
        ge=0.0,
        description="First equilibration delay (seconds)",
    )
    time_equil_2: float = Field(
        default=0.0,
        ge=0.0,
        description="Second equilibration delay (seconds)",
    )
    start_from_observed_by_default: ClassVar[bool] = True

    @computed_field
    @property
    def t_neg(self) -> float:
        """Calculate negative delay compensation for pulse imperfections.

        Returns:
            Negative delay time in seconds.

        """
        return -2.0 * self.pw90 / np.pi

    @computed_field
    @property
    def start_terms(self) -> list[str]:
        """Initial magnetization terms for the experiment.

        Returns:
            List of initial state terms for the Liouvillian calculation.

        """
        return self.get_start_terms("2izsz")

    @computed_field
    @property
    def detection(self) -> str:
        """Detection mode for the observable magnetization.

        Returns:
            Detection term for the Liouvillian calculation.

        """
        return self.get_detection_expression("[iz]")


class Cpmg1HnAp0013Config(
    ExperimentConfiguration[
        Cpmg1HnAp0013Settings,
        ConditionsWithValidations,
        RelaxationDataSettings,
    ],
):
    @property
    def to_be_fitted(self) -> ToBeFitted:
        state = self.experiment.primary_state
        return ToBeFitted(rates=[f"r2_i_{state}"], model_free=[f"tauc_{state}"])


def build_spectrometer(
    config: Cpmg1HnAp0013Config,
    spin_system: SpinSystem,
) -> Spectrometer:
    settings = config.experiment
    conditions = config.conditions

    basis = Basis(type="ixyzsz", spin_system="hn", model=config.model)
    spectrometer = Spectrometer.from_spin_system(spin_system, basis, conditions)

    spectrometer.carrier_i = settings.carrier
    spectrometer.b1_i = 1 / (4.0 * settings.pw90)
    spectrometer.detection = settings.detection

    return spectrometer


class Cpmg1HnAp0013Sequence:
    """Sequence for 1HN anti-phase CPMG experiment with 0013 variant."""

    def __init__(self, settings: Cpmg1HnAp0013Settings) -> None:
        self.settings = settings
        self._phase_cache: dict[float, tuple[Array, Array]] = {}

    def _get_delays(
        self,
        ncycs: Array,
    ) -> tuple[dict[float, float], dict[float, float], list[float]]:
        ncycs_no_ref = ncycs[ncycs > 0]
        tau_cps = {
            ncyc: self.settings.time_t2 / (4.0 * ncyc) - 0.75 * self.settings.pw90
            for ncyc in ncycs_no_ref
        }
        deltas = {
            ncyc: self.settings.pw90 * (self.settings.ncyc_max - ncyc)
            for ncyc in ncycs_no_ref
        }
        deltas[0.0] = self.settings.pw90 * self.settings.ncyc_max
        delays = [
            self.settings.taua,
            self.settings.t_neg,
            self.settings.pw_eburp,
            0.5 * self.settings.pw_reburp,
            self.settings.time_equil_1,
            self.settings.time_equil_2,
            *tau_cps.values(),
            *deltas.values(),
        ]
        return tau_cps, deltas, delays

    def _get_phases(self, ncyc: Array) -> tuple[Array, Array]:
        ncyc_key = float(ncyc)
        if ncyc_key not in self._phase_cache:
            cp_phases1 = np.array(
                [
                    [1, 1, 2, 0, 1, 1, 0, 2, 1, 1, 0, 2, 1, 1, 2, 0],
                    [2, 0, 3, 3, 0, 2, 3, 3, 0, 2, 3, 3, 2, 0, 3, 3],
                ],
            )
            cp_phases2 = np.array(
                [
                    [3, 3, 2, 0, 3, 3, 0, 2, 3, 3, 0, 2, 3, 3, 2, 0],
                    [2, 0, 1, 1, 0, 2, 1, 1, 0, 2, 1, 1, 2, 0, 1, 1],
                ],
            )
            indexes = np.arange(int(ncyc))
            phases1 = np.take(cp_phases1, np.flip(indexes), mode="wrap", axis=1)
            phases2 = np.take(cp_phases2, indexes, mode="wrap", axis=1)
            self._phase_cache[ncyc_key] = (phases1, phases2)
        return self._phase_cache[ncyc_key]

    def calculate(self, spectrometer: Spectrometer, data: Data) -> Array:
        ncycs = data.metadata

        # Calculation of the spectrometers corresponding to all the delays
        tau_cps, deltas, all_delays = self._get_delays(ncycs)
        delays = dict(zip(all_delays, spectrometer.delays(all_delays), strict=True))
        d_neg = delays[self.settings.t_neg]
        d_taua = delays[self.settings.taua]
        d_eburp = delays[self.settings.pw_eburp]
        d_reburp = delays[0.5 * self.settings.pw_reburp]
        d_eq_1 = delays[self.settings.time_equil_1]
        d_eq_2 = delays[self.settings.time_equil_2]
        d_delta = {ncyc: delays[delay] for ncyc, delay in deltas.items()}
        d_cp = {ncyc: delays[delay] for ncyc, delay in tau_cps.items()}

        # Calculation of the spectrometers corresponding to all the pulses
        p90 = spectrometer.p90_i
        p180 = spectrometer.p180_i
        pp90_i = spectrometer.perfect90_i
        pp180_isx = spectrometer.perfect180_i[0] @ spectrometer.perfect180_s[0]

        # Calculation of the propagators for INEPT and purge elements
        inept = pp90_i[1] @ d_taua @ pp180_isx @ d_taua @ pp90_i[0]
        zfilter = spectrometer.zfilter

        # Getting the starting magnetization
        start = spectrometer.get_start_magnetization(terms=self.settings.start_terms)

        # Calculating the central refocusing block
        if self.settings.eburp_flg:
            p180pmy = p180[[1, 3]]
            pp90pmy = spectrometer.perfect90_i[[1, 3]]
            e180e_pmy = pp90pmy @ d_eburp @ p180pmy @ d_eburp @ pp90pmy
            middle = np.stack([p180pmy @ e180e_pmy, e180e_pmy @ p180pmy])
        elif self.settings.reburp_flg:
            pp180pmy = spectrometer.perfect180_i[[1, 3]]
            middle = d_reburp @ pp180pmy @ d_reburp
        else:
            middle = p180[[1, 3]]

        # Calculating the intensities as a function of ncyc
        centre = {0.0: d_eq_2 @ d_delta[0] @ p90[0] @ middle @ p90[0] @ d_eq_1}

        for ncyc in set(ncycs) - {0.0}:
            phases1, phases2 = self._get_phases(ncyc)
            echo = d_cp[ncyc] @ p180 @ d_cp[ncyc]
            cpmg1 = reduce(np.matmul, echo[phases1.T])
            cpmg2 = reduce(np.matmul, echo[phases2.T])
            centre[ncyc] = (
                d_eq_2
                @ d_delta[ncyc]
                @ p90[0]
                @ d_neg
                @ cpmg2
                @ middle
                @ cpmg1
                @ d_neg
                @ p90[0]
                @ d_eq_1
            )

        intst = {
            ncyc: spectrometer.detect(inept @ zfilter @ centre[ncyc] @ start)
            for ncyc in set(ncycs)
        }

        if self.settings.ipap_flg:
            intst = {
                ncyc: intst[ncyc]
                + spectrometer.detect(centre[ncyc] @ zfilter @ inept @ start)
                for ncyc in set(ncycs)
            }

        # Return profile
        return np.array([intst[ncyc] for ncyc in ncycs])

    @staticmethod
    def is_reference(metadata: Array) -> Array:
        return metadata == 0


def create_profile_calculation(
    config: Cpmg1HnAp0013Config,
    spin_system: SpinSystem,
) -> ProfileCalculation:
    return ProfileCalculation(
        spectrometer=build_spectrometer(config, spin_system),
        pulse_sequence=Cpmg1HnAp0013Sequence(config.experiment),
    )


EXPERIMENT_TYPE = cpmg_type(
    name=EXPERIMENT_NAME,
    config_type=Cpmg1HnAp0013Config,
)(create_profile_calculation)


def register() -> None:
    register_experiment_type(EXPERIMENT_TYPE)
